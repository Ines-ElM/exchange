package com.example.currency;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Spinner sp1,sp2;
    EditText ed1;
    Button b1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ed1=findViewById(R.id.txtamount);
        sp1=findViewById(R.id.spdu);
        sp2=findViewById(R.id.spau);
        b1=findViewById(R.id.btn1);

        String[] from={"USD","EUR","MAD"};
        ArrayAdapter ad = new ArrayAdapter<String>( this, com.google.android.material.R.layout.support_simple_spinner_dropdown_item,from);
        sp1.setAdapter(ad);

        String[] to={"EUR","MAD"};
        ArrayAdapter ad1 = new ArrayAdapter<String>( this, com.google.android.material.R.layout.support_simple_spinner_dropdown_item,to);
        String[] to2={"USD","MAD"};
        ArrayAdapter ad2 = new ArrayAdapter<String>( this, com.google.android.material.R.layout.support_simple_spinner_dropdown_item,to2);
        String[] to3={"USD","EUR"};
        ArrayAdapter ad3 = new ArrayAdapter<String>( this, com.google.android.material.R.layout.support_simple_spinner_dropdown_item,to3);


        sp1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(sp1.getSelectedItemPosition()==0){
                    sp2.setAdapter(ad1);
                } else if (sp1.getSelectedItemPosition()==1) {
                    sp2.setAdapter(ad2);


                } else if (sp1.getSelectedItemPosition()==2){
                    sp2.setAdapter(ad3);

                }

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                sp2.setAdapter(ad1);
            }



        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Double tot;
                Double amount = Double.parseDouble(ed1.getText().toString());
                if (amount != null) {
                    if (sp1.getSelectedItem().toString() == "USD" && sp2.getSelectedItem().toString() == "MAD") {
                        tot = amount * 10.34;
                        Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                    } else if (sp1.getSelectedItem().toString() == "USD" && sp2.getSelectedItem().toString() == "EUR") {
                        tot = amount * 0.94;
                        Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                    } else if (sp1.getSelectedItem().toString() == "MAD" && sp2.getSelectedItem().toString() == "USD") {
                        tot = amount * 0.097;
                        Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                    } else if (sp1.getSelectedItem().toString() == "MAD" && sp2.getSelectedItem().toString() == "EUR") {
                        tot = amount * 0.091;
                        Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                    } else if (sp1.getSelectedItem().toString() == "EUR" && sp2.getSelectedItem().toString() == "MAD") {
                        tot = amount * 11.01;
                        Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                    } else if (sp1.getSelectedItem().toString() == "EUR" && sp2.getSelectedItem().toString() == "USD") {
                        tot = amount * 1.06;
                        Toast.makeText(getApplicationContext(), tot.toString(), Toast.LENGTH_LONG).show();
                    }
                } else {
                    String var = "Veulliez saisire une valeur";
                    Toast.makeText(getApplicationContext(), var, Toast.LENGTH_LONG).show();
                }}});
            }
        }
